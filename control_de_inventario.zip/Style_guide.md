GUÍA DE ESTILOS

Tipografía
 -Ubuntu /weight bold (700)

-Roboto/ weigth regular (400)

(Google Fonts)

Colores
#0D47A1 (backgroung-color Navbar)
#F4F7F9 (backgroung-color ProductTable)
#616161 (color títulos)