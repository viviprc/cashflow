<template>
  <div>
    <ProductTable />
  </div>
</template>
<script>
import ProductTable from "../components/ProductTable";
export default {
  name: "Inventory",
  components: {
    ProductTable,
  },
};
</script>